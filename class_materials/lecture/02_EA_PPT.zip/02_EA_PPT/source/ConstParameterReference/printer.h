#pragma once
#include "person.h"

void printCV(person);