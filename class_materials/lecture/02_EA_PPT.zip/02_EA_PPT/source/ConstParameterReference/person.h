#pragma once

typedef struct person {
	char name[50]; //nev a demo kedveert fix merettel
	int salary; //fizetes forintban
	char cv[500000]; //Jo nagy, jelenleg random oneletrajz tag
} person;